#include <stdio.h>
#include <libnet.h>

void __libnet_print_vers(void);

int main(void) {
	__libnet_print_vers();
	exit(0);
}
