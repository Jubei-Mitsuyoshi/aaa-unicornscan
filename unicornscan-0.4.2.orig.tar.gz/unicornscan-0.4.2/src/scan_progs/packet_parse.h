#ifndef _NEWPARSE_H
# define _NEWPARSE_H

void parse_packet(uint8_t * /* user */, const struct pcap_pkthdr * /* phdr */, const uint8_t * /* packet */);

#endif
