#ifndef _MAIN_H
# define _MAIN_H

/* this is too make the makefile look pretty */

#endif
