#ifndef _DATABASE_H
# define _DATABASE_H

void m_database_init(void);
int m_database_output(const void *);
void m_database_fini(void);

#endif
