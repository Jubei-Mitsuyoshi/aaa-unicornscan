#ifndef _LOGININFO_H
# define _LOGININFO_H

#define USERNAME	"scan"
#define PASSWORD	"scanit!"
#define DBHOST		"localhost"
#define DBNAME 		"scan"

#endif
