
void set_ackmode(void);
int get_ackmode(void);
void set_rstmode(void);
void set_fuzzy(void);
/* -l */
/*
find_masq  = 1;
always_sig = 1;
no_banner = 1;
*/


char *p0f_parse(const uint8_t* , uint16_t );
void load_config(void);
